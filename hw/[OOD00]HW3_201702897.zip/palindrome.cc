#include <iostream>
#include "palindrome.h"

using namespace std;

int countPalindrome(unsigned int min, unsigned int max)
{
	int count = 0;

	for(int i = min; i <= max; i++){
		string sNum = to_string(i);
		int length = sNum.length();
		int j = 0;
		bool isPalindrome = true;

		while(j < length && isPalindrome){
			if(sNum[j] != sNum[length - 1 - j])
				isPalindrome = false;
			else
				j++;
		}
		count = isPalindrome ? count + 1 : count;	
	}
	return count;
}
