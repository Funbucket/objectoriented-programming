#ifndef PALINDROME_H
#define PALINDROME_H

int countPalindrome(unsigned int, unsigned int);

#endif
