#include <iostream>
#include "palindrome.h"

using namespace std;

int main(int argc, char *argv[])
{
	unsigned int min = atoi(argv[1]);
	unsigned int max = atoi(argv[2]);
	
	int count = countPalindrome(min, max);
	cout << count << endl;
	return count;
	
}
